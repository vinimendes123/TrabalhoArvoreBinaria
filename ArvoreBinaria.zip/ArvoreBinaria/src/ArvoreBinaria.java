public class ArvoreBinaria {
    private No raiz;

    public ArvoreBinaria() {
        this.raiz = null;
    }

    public No inserir(int valor) {
        No novoNo = new No(valor);
        if (this.raiz == null) {
            this.raiz = novoNo;
        } else {
            No atual = this.raiz;
            No pai = null;
            while (atual != null) {
                if (novoNo.getValor() < atual.getValor()) {
                    pai = atual;
                    atual = atual.getEsq();
                } else {
                    pai = atual;
                    atual = atual.getDir();
                }
            }
            if (novoNo.getValor() < pai.getValor()) {
                pai.setEsq(novoNo);
            } else {
                pai.setDir(novoNo);
            }
        }
        return novoNo;
    }

    public void preOrdem(No no) {
        if(no == null) {
            return;
        }
        System.out.println(no.getValor());
        preOrdem(no.getEsq());
        preOrdem(no.getDir());
    }

    public void emOrdem(No no) {
        if(no == null) {
            return;
        }
        emOrdem(no.getEsq());
        System.out.println(no.getValor());
        emOrdem(no.getDir());
    }

    public void posOrdem(No no) {
        if(no == null) {
            return;
        }
        posOrdem(no.getEsq());
        posOrdem(no.getDir());
        System.out.println(no.getValor());
    }

    public No getRaiz() {
        return this.raiz;
    }

    public boolean remover(int valor) {
        No atual = this.raiz;
        No pai = null;
        boolean filhoEsquerdo = true;

        // Localizar nó a remover e seu pai.
        while (atual != null && atual.getValor() != valor) {
            pai = atual;
            if (valor < atual.getValor()) {
                atual = atual.getEsq();
                filhoEsquerdo = true;
            } else {
                atual = atual.getDir();
                filhoEsquerdo = false;
            }
        }

        if (atual == null) {
            return false;
        }

        // Não tem filho.
        if (atual.getEsq() == null && atual.getDir() == null) {
            if (atual == this.raiz) {
                this.raiz = null;
            } else if (filhoEsquerdo) {
                pai.setEsq(null);
            } else {
                pai.setDir(null);
            }
        }
        // Nó que tem um filho.
        else if (atual.getDir() == null) { // Só tem filho à esquerda
            if (atual == this.raiz) {
                this.raiz = atual.getEsq();
            } else if (filhoEsquerdo) {
                pai.setEsq(atual.getEsq());
            } else {
                pai.setDir(atual.getEsq());
            }
        } else if (atual.getEsq() == null) { // Só tem filho à direita
            if (atual == this.raiz) {
                this.raiz = atual.getDir();
            } else if (filhoEsquerdo) {
                pai.setEsq(atual.getDir());
            } else {
                pai.setDir(atual.getDir());
            }
        }
        //  Nó que possui dois filhos.
        else {
            No suplente = atual.getDir();
            No paiSuplente = atual;

            // Encontrar o menor valor na subárvore direita
            while (suplente.getEsq() != null) {
                paiSuplente = suplente;
                suplente = suplente.getEsq();
            }

            // Substituir o nó a ser removido pelo substituto
            if (suplente != atual.getDir()) {
                paiSuplente.setEsq(suplente.getDir());
                suplente.setDir(atual.getDir());
            }

            if (atual == this.raiz) {
                this.raiz = suplente;
            } else if (filhoEsquerdo) {
                pai.setEsq(suplente);
            } else {
                pai.setDir(suplente);
            }

            suplente.setEsq(atual.getEsq());
        }
        return true;
    }

    }
